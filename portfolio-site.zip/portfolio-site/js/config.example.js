// Fill with your Firebase web config and rename to config.js
window.FIREBASE_CONFIG = undefined;
/*
window.FIREBASE_CONFIG = {
  apiKey: "xxx",
  authDomain: "xxx.firebaseapp.com",
  projectId: "xxx",
  storageBucket: "xxx.appspot.com",
  messagingSenderId: "xxx",
  appId: "1:xxx:web:xxx"
};
*/
